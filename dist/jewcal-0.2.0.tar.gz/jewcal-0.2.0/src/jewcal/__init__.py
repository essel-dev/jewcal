"""Package jewcal."""

from .core import Jewcal
__all__ = ['Jewcal']
