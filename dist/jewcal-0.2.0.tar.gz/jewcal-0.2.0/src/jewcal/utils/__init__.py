"""Package jewcal.utils."""
